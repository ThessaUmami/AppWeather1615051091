import React from 'react';
import PerkiraanCuaca from './src/PrakiraanCuaca';

export default class App extends React.Component {
  render() {
    return (
    <PerkiraanCuaca />
    );
  }
}
